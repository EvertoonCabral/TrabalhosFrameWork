/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proxytrabalho;

/**
 *
 * @author 00210668
 */
public class HighResolutionImage implements Image{
    
    
    
    private String imagePath;

    public HighResolutionImage(String imagePath) {
        this.imagePath = imagePath;
        loadFromDisk(imagePath);
    }

    @Override
    public void display() {
        System.out.println("Displaying " + imagePath);
    }

    private void loadFromDisk(String path) {
        System.out.println("Loading " + path);
    }
    
}
