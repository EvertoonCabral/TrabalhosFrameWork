package com.mycompany.chainofresponsability;

/**
 *
 * @author 00210668
 */
public class EnvioComprovanteHandler implements Handler {
    private Handler next;

    @Override
    public void setNext(Handler handler) {
        this.next = handler;
    }

    @Override
    public void handleRequest(Solicitation request) {
        if (!request.isCLevel()) {
            System.out.println("Processando Envio de Comprovantes");
        }
        if (next != null) {
            next.handleRequest(request);
        }
    }
}