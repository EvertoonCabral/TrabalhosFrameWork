    
package com.mycompany.chainofresponsability;

/**
 *
 * @author 00210668
 */
public interface Handler {
    void setNext(Handler handler);
    void handleRequest(Solicitation request);
}

