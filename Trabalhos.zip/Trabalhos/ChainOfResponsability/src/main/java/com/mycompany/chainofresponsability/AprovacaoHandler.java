package com.mycompany.chainofresponsability;

/**
 *
 * @author 00210668
 */
public class AprovacaoHandler implements Handler {
    private Handler next;

    @Override
    public void setNext(Handler handler) {
        this.next = handler;
    }

    @Override
    public void handleRequest(Solicitation request) {
        System.out.println("Processando Aprovação");
        if (next != null) {
            next.handleRequest(request);
        }
    }
}
