package com.mycompany.chainofresponsability;

/**
 *
 * @author 00210668
 */
public class PedidoHandlerHandler implements Handler {
    private Handler next;

    @Override
    public void setNext(Handler handler) {
        this.next = handler;
    }

    @Override
    public void handleRequest(Solicitation request) {
        System.out.println("Processando Pedido");
        if (next != null) {
            next.handleRequest(request);
        }
    }
}







