
package com.mycompany.chainofresponsability;

/**
 *
 * @author 00210668
 */
public class Main {
    public static void main(String[] args) {
        Handler pedido = new PedidoHandlerHandler();
        Handler envioComprovantes = new EnvioComprovanteHandler();
        Handler analise = new AnaliseHandler();
        Handler aprovacao = new AprovacaoHandler();

        // Configuração da cadeia
        pedido.setNext(envioComprovantes);
        envioComprovantes.setNext(analise);
        analise.setNext(aprovacao);

        // Processando uma solicitação normal
        System.out.println("Solicitação Normal:");
        Solicitation normalRequest = new Solicitation(false);
        pedido.handleRequest(normalRequest);

        // Processando uma solicitação de um funcionário C-Level
        System.out.println("\nSolicitação C-Level:");
        Solicitation cLevelRequest = new Solicitation(true);
        pedido.handleRequest(cLevelRequest);
    }
}

