
package com.mycompany.chainofresponsability;

/**
 *
 * @author 00210668
 */
public class Solicitation {
    private boolean isCLevel;

    public Solicitation(boolean isCLevel) {
        this.isCLevel = isCLevel;
    }

    public boolean isCLevel() {
        return isCLevel;
    }
}

