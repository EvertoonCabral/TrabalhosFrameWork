
package com.mycompany.templatemethod;

/**
 *
 * @author 00210668
 */
public class ConhecimentoTransporte extends DocumentoFiscal {

    @Override
    protected void salvar() {
        System.out.println("Salvando Conhecimento de Transporte");
    }

    @Override
    protected void transmitir() {
        System.out.println("Transmitindo Conhecimento de Transporte");
    }

    @Override
    protected void consultar() {
        System.out.println("Consultando Conhecimento de Transporte");
    }

    @Override
    protected void cancelar() {
        System.out.println("Cancelando Conhecimento de Transporte");
    }

    @Override
    protected void inutilizarNumeracao() {
        System.out.println("Inutilizando numeração do Conhecimento de Transporte");
    }
}
