
package com.mycompany.templatemethod;


public abstract class DocumentoFiscal {
    
    
    public final void processarDocumento() {
        salvar();
        transmitir();
        consultar();
        cancelar();
        inutilizarNumeracao();
    }

    protected abstract void salvar();
    protected abstract void transmitir();
    protected abstract void consultar();
    protected abstract void cancelar();
    protected abstract void inutilizarNumeracao();
    
    
}
