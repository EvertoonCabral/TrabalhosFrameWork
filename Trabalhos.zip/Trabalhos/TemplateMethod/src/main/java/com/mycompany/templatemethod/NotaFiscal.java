/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.templatemethod;

/**
 *
 * @author 00210668
 */
public class NotaFiscal extends DocumentoFiscal {

    @Override
    protected void salvar() {
        System.out.println("Salvando Nota Fiscal");
    }

    @Override
    protected void transmitir() {
        System.out.println("Transmitindo Nota Fiscal");
    }

    @Override
    protected void consultar() {
        System.out.println("Consultando Nota Fiscal");
    }

    @Override
    protected void cancelar() {
        System.out.println("Cancelando Nota Fiscal");
    }

    @Override
    protected void inutilizarNumeracao() {
        System.out.println("Inutilizando numeração da Nota Fiscal");
    }
}


