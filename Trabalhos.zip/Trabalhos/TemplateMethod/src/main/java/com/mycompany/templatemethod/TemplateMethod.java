
package com.mycompany.templatemethod;

/**
 *
 * @author 00210668
 */
public class TemplateMethod {

    public static void main(String[] args) {
        DocumentoFiscal notaFiscal = new NotaFiscal();
        notaFiscal.processarDocumento();

        DocumentoFiscal conhecimentoTransporte = new ConhecimentoTransporte();
        conhecimentoTransporte.processarDocumento();
    }
}
