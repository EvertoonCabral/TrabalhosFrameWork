
package com.mycompany.facadetrabalho;

import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;

public class TwitterFacade {
    private String consumerKey;
    private String consumerSecret;
    private String baseUrl = "https://api.twitter.com/";

    public TwitterFacade(String consumerKey, String consumerSecret) {
        this.consumerKey = consumerKey;
        this.consumerSecret = consumerSecret;
    }

    private String getRequestToken() {

        return "requestToken";
    }

    private String getAccessToken(String requestToken) {
 
        return "accessToken";
    }

    public String getTweets(String userId) {
        String requestToken = getRequestToken();
        String accessToken = getAccessToken(requestToken);

        return "tweets";
    }

}
